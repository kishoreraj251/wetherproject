const apiKey = 'YOUR_API_KEY_HERE'; // Replace with your OpenWeatherMap API key
const searchBtn = document.getElementById('searchBtn');
const geoBtn = document.getElementById('geoBtn');
const weatherDisplay = document.getElementById('weatherDisplay');

searchBtn.addEventListener('click', () => {
    const location = document.getElementById('locationInput').value;
    if (location) {
        fetchWeatherByCity(location);
    } else {
        alert('Please enter a city name');
    }
});

geoBtn.addEventListener('click', () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            const lat = position.coords.latitude;
            const lon = position.coords.longitude;
            fetchWeatherByCoordinates(lat, lon);
        }, () => {
            alert('Could not get your location');
        });
    } else {
        alert('Geolocation is not supported by your browser');
    }
});

function fetchWeatherByCity(city) {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`;
    fetchWeatherData(url);
}

function fetchWeatherByCoordinates(lat, lon) {
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&appid=${apiKey}`;
    fetchWeatherData(url);
}

function fetchWeatherData(url) {
    fetch(url)
        .then(response => response.json())
        .then(data => displayWeatherData(data))
        .catch(error => console.error('Error fetching weather data:', error));
}

function displayWeatherData(data) {
    const city = `${data.name}, ${data.sys.country}`;
    const temperature = `Temperature: ${data.main.temp}°C`;
    const condition = `Condition: ${data.weather[0].description}`;
    const additionalInfo = `Humidity: ${data.main.humidity}% | Wind Speed: ${data.wind.speed} m/s`;

    document.getElementById('city').innerText = city;
    document.getElementById('temperature').innerText = temperature;
    document.getElementById('condition').innerText = condition;
    document.getElementById('additional').innerText = additionalInfo;

    weatherDisplay.style.display = 'block';
}
